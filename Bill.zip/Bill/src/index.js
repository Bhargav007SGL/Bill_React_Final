import React from "react";
import ReactDOM from "react-dom";
import './bill.css';
import sgllogo from './SGL-LOGO.png'

function Bill() {

  function printSpecificPortion()
{
    var printContent = document.getElementById("billprint");
    var WinPrint = window.open('', '', 'width=1200,height=650');
    
    WinPrint.document.write(`<html><head>`);
    WinPrint.document.write(`<style>`);
    WinPrint.document.write(`
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td {
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    .invoice-box.rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .invoice-box.rtl table {
        text-align: right;
    }
    
    .invoice-box.rtl table tr td:nth-child(2) {
        text-align: left;
    }
    
    
    #imagelogo
    {
        top: 11%;
        height: 81px;
        width: 140px;
    }    
    `);
    WinPrint.document.write(`</style>`);
    WinPrint.document.write(`</head>`);
    WinPrint.document.write(`<body>`);
    WinPrint.document.write(printContent.innerHTML);
    WinPrint.document.write(`</body>`);
    WinPrint.document.write(`</html>`);
    WinPrint.document.close();
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
}

  function callme()
{
    // Event.preventDefault();
    // window.print();
    document.getElementById("billfname").innerHTML =  document.getElementById("fname").value;
    document.getElementById("billlname").innerHTML =  document.getElementById("lname").value;
    document.getElementById("billlemail").innerHTML =  document.getElementById("email").value;
    document.getElementById("billlmono").innerHTML =  document.getElementById("mono").value;
    document.getElementById("billpincode").innerHTML =  document.getElementById("pincode").value;
    document.getElementById("billstate").innerHTML =  document.getElementById("state").value;
    document.getElementById("billaddress").innerHTML =  document.getElementById("address").value;
    document.getElementById("billno").innerHTML = Math.floor(Math.random() * 100);
    var date  = new Date();
    var sDate = date.toString();
    sDate =  sDate.slice(0,sDate.search(":") - 2);
    document.getElementById("billdate").innerHTML = sDate;
    if(document.getElementById("payment").value === "Paytm")
    {
    document.getElementById("billpayment").innerHTML = "Paytm";
    }
    else if(document.getElementById("payment").value === "GooglePay")
    {
    document.getElementById("billpayment").innerHTML = "Google Pay";
    }
    else
    {
    document.getElementById("billpayment").innerHTML = "PhonePe";
    }
    printSpecificPortion();
}

  return (
    <>
      <div style = {{display:"none"}} id="billprint">
        <div className="invoice-box">
          <table cellPadding="0" cellSpacing="0">
            <tbody>
            <tr className="top">
              <td colSpan="2">
                <table>
                  <tbody>
                  <tr>
                    <td className="title">
                      <img src={sgllogo} id="imagelogo" alt='Not Loaded' />
                    </td>
                    <td>
                      Bill No #: <span id="billno"></span><br />
                      Created: <span id="billdate"></span><br />
                    </td>
                  </tr>
                  </tbody>
                </table>
              </td>
            </tr>

            <tr className="information">
              <td colSpan="2">
                <table>
                  <tbody>
                  <tr>
                    <td>
                      <span id="billpincode"></span>
                      <br />
                      <span id="billaddress"></span>
                      <br />
                      <span id="billstate"></span>
                    </td>
                    <td>
                      <span id="billfname"></span>
                      <br />
                      <span id="billlname"></span>
                      <br />
                      <span id="billlemail"></span>
                      <br />
                      <span id="billlmono"></span>
                    </td>
                  </tr>
                  </tbody>
                </table>
              </td>
            </tr>

            <tr className="heading">
              <td>Payment Method</td>
            </tr>

            <tr className="details">
              <td><span id="billpayment"></span></td>

              <td>₹36000</td>
            </tr>

            <tr className="heading">
              <td>Item</td>

              <td>Price</td>
            </tr>

            <tr className="item">
                <td>PC</td>

                <td>₹15000.00</td>
            </tr>

            <tr className="item">
                <td>CPU</td>

                <td>₹20000.00</td>
            </tr>

            <tr className="item">
                <td>Mouse</td>

                <td>₹1000.00</td>
            </tr> 


            <tr className="total">
              <td></td>

              <td>Total: ₹36000.00</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>

     <form action="">
     <div className="row">
            <div className="col-25">
              <label htmlFor="fname">First Name</label>
            </div>
            <div className="col-75">
              <input type="text" id="fname" name="firstname" placeholder="Your name.." required/>
            </div>
       </div>

       <div className="row">
            <div className="col-25">
              <label htmlFor="lname">Last Name</label>
            </div>
            <div className="col-75">
              <input type="text" id="lname" name="lastname" placeholder="Your last name.." required/>
            </div>
      </div>
          <div className="row">
            <div className="col-25">
              <label htmlFor="mono">Mobile Number</label>
            </div>
            <div className="col-75">
              <input type="tel" id="mono" name="mono" placeholder="Your Mobile Number.." required/>
            </div>
          </div>

          <div className="row">
            <div className="col-25">
              <label htmlFor="email">Email Address</label>
            </div>
            <div className="col-75">
              <input type="email" id="email" name="email" placeholder="Your Email Address.." required/>
            </div>
          </div>

          <div className="row">
            <div className="col-25">
              <label htmlFor="payment">Payment Method</label>
            </div>
            <div className="col-75">
              <select id="payment" name="payment" required>
                <option value="Paytm">Paytm</option>
                <option value="GooglePay">Google Pay</option>
                <option value="PhonePe">PhonePe</option>
              </select>
            </div>
          </div>

          <div className="row">
            <div className="col-25">
              <label htmlFor="state">State</label>
            </div>
            <div className="col-75">
              <input type="text" id="state" name="state" placeholder="Your State..." required/>
            </div>
          </div>

          <div className="row">
            <div className="col-25">
              <label htmlFor="pincode">Pin Code</label>
            </div>
            <div className="col-75">
              <input type="number" id="pincode" name="pincode" placeholder="Your Pincode..." required/>
            </div>
          </div>

          <div className="row">
            <div className="col-25">
              <label htmlFor="address">Address</label>
            </div>
            <div className="col-75">
              <textarea id="address" name="address" placeholder="Your Address" style={{height:'200px'}} required></textarea>
            </div>
          </div>

          <div className="row">
            <input type="button" value="Submit" onClick={callme}/>
          </div>

     </form>
      </>
  )
}

ReactDOM.render(<Bill />, document.getElementById("root"));